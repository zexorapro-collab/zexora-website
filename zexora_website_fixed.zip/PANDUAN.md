# Panduan Zexora Pro — Website + Hosting + Domain (untuk Pemula)

Website ini adalah **website statis** (HTML/CSS/JS biasa), jadi tidak butuh
server rumit atau coding tambahan. Anda hanya perlu meng-upload 3 file ini
ke layanan hosting.

## 1. Isi folder

```
index.html   → halaman utama
style.css    → semua tampilan/desain
script.js    → link tombol Play Store + menu mobile
```

## 2. WAJIB: Ganti link Play Store dulu

Buka file `script.js`, baris paling atas ada:

```js
const PLAYSTORE_URL = "https://play.google.com/store/apps/details?id=com.zexora.pro";
```

Ganti bagian URL itu dengan link Play Store aplikasi Zexora Pro Anda yang
sebenarnya. Cukup ubah **satu baris ini saja** — semua tombol "Coba Gratis",
"Download Sekarang", "Download di Google Play", dll di seluruh halaman akan
otomatis ikut berubah.

## 3. Coba dulu di komputer Anda (opsional)

Cukup klik dua kali file `index.html`, akan terbuka di browser. Kalau sudah
sesuai keinginan, lanjut ke langkah hosting di bawah.

---

## 4. Cara Hosting (GRATIS) — cara paling mudah untuk pemula

Rekomendasi: **Netlify**. Gratis, tidak perlu kartu kredit, tidak perlu coding.

1. Buka https://app.netlify.com dan daftar (bisa pakai akun Google/GitHub).
2. Setelah masuk ke dashboard, cari kotak bertuliskan **"Drag and drop your
   site output folder here"**.
3. Buka folder `zexora` di komputer Anda, **seret (drag) seluruh folder itu**
   ke kotak tersebut.
4. Tunggu beberapa detik — Netlify otomatis memberi Anda alamat website,
   contoh: `https://nama-acak-123.netlify.app`.
5. Website Anda sudah **online dan bisa diakses siapa saja** lewat link itu.

Alternatif lain yang sama mudahnya: **Vercel** (vercel.com) atau
**GitHub Pages** (perlu akun GitHub, upload file ke repository lalu aktifkan
Pages di Settings).

---

## 5. Cara Beli Domain (misal: zexorapro.com)

Domain adalah nama alamat website Anda (mis. `zexorapro.com`) supaya tidak
memakai alamat acak dari Netlify.

Pilihan penyedia domain:

| Lokal (bayar Rupiah, IDR) | Internasional (bayar USD) |
|---|---|
| Niagahoster (niagahoster.co.id) | Namecheap (namecheap.com) |
| Rumahweb (rumahweb.com) | Google Domains / Squarespace Domains |
| Domainesia (domainesia.com) | Cloudflare Registrar |

Langkah umum (mirip di semua penyedia):

1. Buka salah satu situs di atas, cari domain yang Anda inginkan
   (contoh: `zexorapro.com` atau `zexorapro.id`).
2. Kalau tersedia, tambahkan ke keranjang lalu checkout dan bayar
   (harga umumnya Rp100rb–Rp250rb/tahun untuk `.com`, lebih murah untuk `.id`
   kadang perlu KTP untuk verifikasi domain `.id`).
3. Setelah dibayar, domain otomatis jadi milik Anda selama masa aktif
   (biasanya 1 tahun, perlu diperpanjang/renew tiap tahun).

---

## 6. Menghubungkan Domain ke Netlify

Setelah punya domain dan website sudah online di Netlify:

1. Di dashboard Netlify, buka situs Anda → **Site settings** → **Domain
   management** → **Add a domain**.
2. Ketik domain Anda (contoh: `zexorapro.com`), klik **Verify** lalu
   **Add domain**.
3. Netlify akan menampilkan 2 kemungkinan cara:
   - **Cara mudah**: kalau domain dibeli di Niagahoster/Namecheap/dll,
     Netlify akan minta Anda mengubah **Nameserver** domain menjadi
     nameserver milik Netlify (Netlify akan menampilkan 4 alamat
     nameserver). Masuk ke akun penyedia domain Anda → cari menu
     **Nameserver/DNS** → ganti dengan nameserver dari Netlify tersebut.
   - **Cara alternatif**: tambahkan **DNS record** tipe `A` dan `CNAME`
     sesuai instruksi yang Netlify tampilkan, tanpa mengganti nameserver.
4. Tunggu propagasi DNS (biasanya 15 menit – 24 jam). Setelah selesai,
   website Anda otomatis bisa diakses lewat domain sendiri, contoh
   `https://zexorapro.com`, lengkap dengan HTTPS (gembok aman) otomatis
   dari Netlify — gratis, tanpa perlu beli SSL terpisah.

---

## 7. Checklist sebelum go-live

- [ ] Link Play Store di `script.js` sudah diganti dengan link asli
- [ ] Email di footer (`halo@zexorapro.com`) sudah diganti dengan email asli Anda
- [ ] Nomor telepon di footer sudah diganti dengan nomor asli
- [ ] Sudah dicoba buka di HP (tampilan mobile) — buka link Netlify dari HP
- [ ] Domain sudah terhubung (opsional, bisa menyusul)

---

## 8. Kalau ingin ubah teks/warna/tampilan nanti

- Semua **teks** ada di `index.html` — cari kalimatnya, ganti langsung.
- Semua **warna & jarak/spacing** ada di `style.css`, di bagian paling atas
  (`:root { ... }`) — misalnya ganti `--accent-cyan: #22d3ee;` ke warna lain
  untuk ganti warna utama di seluruh halaman sekaligus.
- Setiap selesai edit, cukup upload ulang folder ke Netlify (drag & drop
  lagi ke situs yang sama, atau hubungkan ke GitHub agar otomatis update).
